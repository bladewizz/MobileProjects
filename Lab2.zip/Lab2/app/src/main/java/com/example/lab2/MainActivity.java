package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    RadioGroup myRG1;
    RadioGroup myRG2;
    SeekBar mySB;
    CheckBox cb1, cb2, cb3, cb4;
    TextView size;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myRG1 = (RadioGroup) findViewById(R.id.crust_group);
        myRG2 = (RadioGroup) findViewById(R.id.location);
        mySB = (SeekBar) findViewById(R.id.size_seek);
        size = (TextView) findViewById(R.id.seek_display);






        mySB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                size.setText(Integer.toString(progress)+" in");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }


}
